# Firebase Invites

Firebase Invites is deprecated. You can create cross-platform invitation links that survive app installation using [Firebase Dynamic Links][fdl]. Please see [Migration Guide][migration] for more details.

For an example of how to use Dynamic Links to invite users to your application, see [Invite Users to Your App][user-to-user].

[fdl]:https://firebase.google.com/docs/dynamic-links/
[migration]:https://firebase.google.com/docs/invites/deprecation
[user-to-user]:https://firebase.google.com/docs/dynamic-links/use-cases/user-to-user